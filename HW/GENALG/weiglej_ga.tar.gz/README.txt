Justin Weigle
HW 3 - Genetic Algorithm
Using python 3.7.4(home) and 3.6.8(Ship)
To run:
    python weiglej_ga.py      *on most machines
    python3 weiglej_ga.py     *on campus machines
