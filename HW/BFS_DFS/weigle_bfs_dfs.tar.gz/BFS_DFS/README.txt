Justin Weigle
HW 1 - BFS_DFS
Using python 3.7.4(home) and 3.6.8(Ship)
To run:
    python weiglebfs-dfs.py      *on most machines
    python3 weiglebfs-dfs.py     *on campus machines
