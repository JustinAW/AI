Justin Weigle
HW 2 - A*
Using python 3.7.4(home) and 3.6.8(Ship)
To run:
    python weigle-astar.py      *on most machines
    python3 weigle-astar.py     *on campus machines
